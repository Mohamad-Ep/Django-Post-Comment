--
-- PostgreSQL database dump
--

\restrict AdbcQ9PbbBwJz1K35znkuncsQZPsX5t4uY7i8pzsxZ24qnI1de5rlIO5V8gZOXF

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: accounts_customuser; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.accounts_customuser (id, password, last_login, is_superuser, email, created_date, updated_date, is_active, is_admin, is_verified) FROM stdin;
2	pbkdf2_sha256$1000000$P9n5OBcqH6GStjSUGdyAxn$LEg8VgtWoNgBQXThRDIs9WRSccrhN9HdXED0+Yi8vhY=	\N	f	hasan_rajabi@gmail.com	2025-10-18 16:57:46.252576+00	2025-10-18 16:58:07.067399+00	t	f	f
9	Aa123456@	\N	f	simpsonnicholas@example.com	2025-10-31 09:51:10.538976+00	2025-10-31 09:51:10.538988+00	f	f	f
10	Aa123456@	\N	f	mark83@example.net	2025-10-31 09:53:42.476581+00	2025-10-31 09:53:42.476592+00	f	f	f
3	pbkdf2_sha256$1000000$aMWyEf8QWN3QiNlsXY0Yo0$XhTovqbYk/sSWzARwtv2FaRJEhWNNMsZ6cHMmTqAKZ0=	2025-10-19 10:26:26.115579+00	f	sanaz.bahrami123@yahoo.com	2025-10-18 17:17:28.028079+00	2025-10-18 17:17:28.028141+00	t	f	f
11	Aa123456@	\N	f	pmckinney@example.net	2025-10-31 09:56:17.195735+00	2025-10-31 09:56:17.195746+00	f	f	f
5	pbkdf2_sha256$1000000$IUDixKFjY2Dk6KHk7MBrbO$ifQFXAiV3ktzPmiun7IPxWqWnWqHmBAlV8hhJHpE+pU=	\N	f	hasan.gharizi74@gmail.com	2025-10-20 09:33:02.392402+00	2025-10-20 09:33:02.392423+00	t	f	f
12	Aa123456@	\N	f	christine42@example.net	2025-10-31 10:15:39.030946+00	2025-10-31 10:15:39.030958+00	f	f	f
13	Aa123456@	\N	f	wolfdonald@example.org	2025-10-31 10:15:58.45422+00	2025-10-31 10:15:58.454231+00	f	f	f
1	pbkdf2_sha256$1000000$Mq9WI0uHyEZazScaRRVZ3h$ZYYA28U5GKNAt/nA05iMT65r5vkYtiITTqEnnBBswEU=	2025-11-09 05:28:28.591255+00	t	admin@gmail.com	2025-10-18 15:59:30.021908+00	2025-10-18 15:59:30.021953+00	t	t	f
6	pbkdf2_sha256$1000000$gBCNZ9O5KuNK3M4ZZQwgB7$UxrMw55S2tT4e5tHw/a1HxF2NU+RVFzBrDtruHc1C1E=	2025-11-09 05:36:26.039613+00	f	reza_bakht@gmail.com	2025-10-20 09:50:31.701942+00	2025-10-20 09:56:40.284007+00	t	f	t
4	pbkdf2_sha256$1000000$PbJpoHMGsbwpV03F442oN0$ZXVjkvyt9Amx5pjnhVx7mRiW/UFT1akYl/HrtnbWbJQ=	2025-10-23 14:11:36.087603+00	f	reyhaneh.asar@gmail.com	2025-10-19 09:39:30.956292+00	2025-10-19 09:39:30.956305+00	t	f	f
8	pbkdf2_sha256$1000000$9JhcJN5FylVvUjv8P0WavT$0HgfibzgYm+UWeQIlrymFdA8zGWaJlvH3wUSRSkvGTE=	2025-10-26 11:30:47.766852+00	f	alimoradi124@gmail.com	2025-10-20 09:57:49.814061+00	2025-10-21 14:48:51.497088+00	t	f	t
7	pbkdf2_sha256$1000000$Qb3AFw8araUGti6HsW9BK2$mePvn6NEa+TYUeLce/IH6iAl4sdfBPoDRwEqVY2QO84=	2025-10-27 20:57:08.909527+00	f	sana_bakhshi@gmail.com	2025-10-20 09:54:03.058601+00	2025-10-21 14:58:12.609398+00	t	f	t
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: accounts_customuser_groups; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.accounts_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	accounts	customuser
7	accounts	profile
34	authtoken	token
35	authtoken	tokenproxy
36	django_celery_beat	crontabschedule
37	django_celery_beat	intervalschedule
38	django_celery_beat	periodictask
39	django_celery_beat	periodictasks
40	django_celery_beat	solarschedule
41	django_celery_beat	clockedschedule
42	blog	category
43	blog	article
44	comments	blogcomment
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add کاربر	6	add_customuser
22	Can change کاربر	6	change_customuser
23	Can delete کاربر	6	delete_customuser
24	Can view کاربر	6	view_customuser
25	Can add پروفایل کاربر	7	add_profile
26	Can change پروفایل کاربر	7	change_profile
27	Can delete پروفایل کاربر	7	delete_profile
28	Can view پروفایل کاربر	7	view_profile
34	Can add Token	34	add_token
35	Can change Token	34	change_token
36	Can delete Token	34	delete_token
37	Can view Token	34	view_token
38	Can add Token	35	add_tokenproxy
39	Can change Token	35	change_tokenproxy
40	Can delete Token	35	delete_tokenproxy
41	Can view Token	35	view_tokenproxy
42	Can add crontab	36	add_crontabschedule
43	Can change crontab	36	change_crontabschedule
44	Can delete crontab	36	delete_crontabschedule
45	Can view crontab	36	view_crontabschedule
46	Can add interval	37	add_intervalschedule
47	Can change interval	37	change_intervalschedule
48	Can delete interval	37	delete_intervalschedule
49	Can view interval	37	view_intervalschedule
50	Can add periodic task	38	add_periodictask
51	Can change periodic task	38	change_periodictask
52	Can delete periodic task	38	delete_periodictask
53	Can view periodic task	38	view_periodictask
54	Can add periodic task track	39	add_periodictasks
55	Can change periodic task track	39	change_periodictasks
56	Can delete periodic task track	39	delete_periodictasks
57	Can view periodic task track	39	view_periodictasks
58	Can add solar event	40	add_solarschedule
59	Can change solar event	40	change_solarschedule
60	Can delete solar event	40	delete_solarschedule
61	Can view solar event	40	view_solarschedule
62	Can add clocked	41	add_clockedschedule
63	Can change clocked	41	change_clockedschedule
64	Can delete clocked	41	delete_clockedschedule
65	Can view clocked	41	view_clockedschedule
66	Can add دسته بندی مقاله	42	add_category
67	Can change دسته بندی مقاله	42	change_category
68	Can delete دسته بندی مقاله	42	delete_category
69	Can view دسته بندی مقاله	42	view_category
70	Can add مقاله	43	add_article
71	Can change مقاله	43	change_article
72	Can delete مقاله	43	delete_article
73	Can view مقاله	43	view_article
74	Can add blog comment	44	add_blogcomment
75	Can change blog comment	44	change_blogcomment
76	Can delete blog comment	44	delete_blogcomment
77	Can view blog comment	44	view_blogcomment
\.


--
-- Data for Name: accounts_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.accounts_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.


--
-- Data for Name: accounts_profile; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.accounts_profile (id, name, family, mobile_number, created_date, updated_date, image_name, gender, user_id) FROM stdin;
1	\N	\N	\N	2025-10-18 15:59:30.029172+00	2025-10-18 15:59:30.029183+00		Unknown	1
2	\N	\N	\N	2025-10-18 16:57:46.254324+00	2025-10-18 16:57:46.254332+00		Unknown	2
3	\N	\N	\N	2025-10-18 17:17:28.045517+00	2025-10-18 17:17:28.045529+00		Unknown	3
4	\N	\N	\N	2025-10-19 09:39:30.961707+00	2025-10-19 09:39:30.961717+00		Unknown	4
5	\N	\N	\N	2025-10-20 09:33:02.403775+00	2025-10-20 09:33:02.403791+00		Unknown	5
7	\N	\N	\N	2025-10-20 09:54:03.063153+00	2025-10-20 09:54:03.063162+00		Unknown	7
8	\N	\N	\N	2025-10-20 09:57:49.817254+00	2025-10-20 09:57:49.817263+00		Unknown	8
6	رضا	بختیاری	\N	2025-10-20 09:50:31.705546+00	2025-10-27 15:37:12.809402+00		man	6
9	Randall	Roberts	\N	2025-10-31 09:51:10.544852+00	2025-10-31 09:51:10.5496+00		Unknown	9
10	Janet	Shah	\N	2025-10-31 09:53:42.481138+00	2025-10-31 09:53:42.484971+00		Unknown	10
11	Misty	Adams	\N	2025-10-31 09:56:17.199128+00	2025-10-31 09:56:17.202116+00		Unknown	11
12	Isabella	Steele	\N	2025-10-31 10:15:39.035197+00	2025-10-31 10:15:39.038622+00		Unknown	12
13	Angela	Boyle	\N	2025-10-31 10:15:58.45785+00	2025-10-31 10:15:58.461286+00		Unknown	13
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
d68c7c7e5d042063ed2eebe7c70232f6d5563d82	2025-10-20 15:13:48.911157+00	6
bd8f38266840037e4b78d95eec7209a2dd1cc88e	2025-10-22 09:54:14.826242+00	8
\.


--
-- Data for Name: blog_category; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.blog_category (id, category_title, summary_description, created_date, is_active) FROM stdin;
1	علمی	\N	2025-10-26 11:06:40.959775+00	t
2	تکنولوژی	\N	2025-10-26 11:06:48.404495+00	t
3	پژوهشی	\N	2025-10-26 11:07:09.11213+00	t
4	پزشکی	\N	2025-10-26 11:07:49.968771+00	t
\.


--
-- Data for Name: blog_article; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.blog_article (id, article_title, article_text, is_active, created_date, updated_date, published_date, slug, image_name, author_id, category_id) FROM stdin;
1	نبرد هدست‌های پرچمدار؛ مقایسه گلکسی XR سامسونگ با ویژن پرو اپل	دنیای هدست‌های واقعیت ترکیبی (XR) در سال 2025 وارد مرحله‌ جدیدی شده است. پس از اپل ویژن پرو، حالا سامسونگ نیز با همکاری گوگل و کوالکام وارد میدان شده و اولین نسخه از هدست گلکسی XR را معرفی کرده است. در ادامه این دو هدست را از نظر طراحی، عملکرد، نمایشگر، نرم‌افزار، تجربه‌کاربری و قیمت با هم مقایسه می‌کنیم.	t	2025-10-26 11:08:45.018527+00	2025-10-26 11:08:45.064094+00	2025-10-26 11:08:44.953881+00	samsung-xr-headset-vs-apple-vision-pro-spec	images/blog/article/apple-samsung8655963392.webp	6	2
2	چین رباتی شبیه عروس دریایی برای مأموریت‌های مخفیانه زیر آب معرفی کرد	ربات مذکور که ظاهری شفاف دارد توسط تیمی از دانشکده مهندسی مکانیک و برق دانشگاه پلی‌تکنیک شمال‌غرب چین ساخته شده است. آنها برای ساخت ربات خود، حرکات و ظاهر یک عروس دریایی واقعی را شبیه‌سازی کرده‌اند. بدنه نرم و چتری‌شکل و سامانه پیشران سیال ربات، باعث می‌شود به‌آرامی و تقریباً بدون امکان تشخیص توسط سنسورها یا چشم انسان در آب حرکت کند.	t	2025-10-26 11:14:52.922993+00	2025-10-26 11:14:52.967523+00	2025-10-26 11:14:52.919902+00	china-jellyfish-like-drone-underwater-missions	images/blog/article/jellyfish-robot68348.webp	6	2
3	دانشمندان ژاپنی یک گام به توسعه باتری‌های کوانتومی نزدیک‌تر شدند	در سال‌های اخیر به‌دلیل نگرانی‌های زیست‌محیطی، دانشمندان به‌دنبال روش‌های نوین ذخیره‌سازی انرژی بوده‌اند. اکنون در این مسیر محققان ژاپنی به پیشرفت نظری شگفت‌انگیزی رسیده‌اند؛ آنها توانستند مانع اصلی توسعه باتری‌های کوانتومی (اتلاف انرژی) را برطرف کنند. این دستاورد که درحال‌حاضر در قالب چارچوب نظری ارائه شده، می‌تواند نحوه ذخیره و انتقال نیرو را در آینده به کلی متحول کند.	t	2025-10-26 11:17:07.995106+00	2025-10-26 11:17:08.018171+00	2025-10-26 11:17:07.991146+00	japan-topological-quantum-battery	images/blog/article/japan-topological-quantumwebp25311.webp	6	1
4	قدرتمندترین لیزر آمریکا برای اولین‌بار با توان 2 پتاوات شلیک کرد	به گزارش Scitechdaily، این انفجار عظیم که بیش از ۱۰۰ برابر کل برق تولیدشده در جهان است، تنها برای بازه‌ای فوق‌العاده کوتاه از یک پالس لیزر پایدار است، یعنی ۲۵ کوینتیلیونیم ثانیه. «کارل کروشلنیک»، مدیر مرکز Gérard Mourou برای علوم نوری فوق‌سریع که میزبان تأسیسات لیزری ZEUS است، گفت: «این دستاورد آغاز آزمایش‌هایی است که وارد قلمرو ناشناخته‌ای برای علوم میدان بالا در آمریکا می‌شوند.»	t	2025-10-26 11:24:53.153724+00	2025-10-26 11:24:53.216055+00	2025-10-26 11:24:53.149606+00	americas-most-powerful-laser-2-petawatt-shot	images/blog/article/View-Through-a-Titanium-Sapphirewebp63918.webp	6	1
5	شرکت OpenAI هوش مصنوعی جدیدی برای تولید موسیقی توسعه می‌دهد	براساس گزارش The Information، شرکت OpenAI درحال کار روی ابزاری جدید است که می‌تواند براساس متن و ورودی‌های صوتی، برای کاربران موسیقی تولید کند. به گفته منابع آگاه، چنین ابزاری می‌تواند برای افزودن موسیقی به ویدیوهای موجود یا اضافه‌کردن موسیقی گیتار به یک ترک صوتی با صدای خواننده استفاده شود.	t	2025-10-26 11:27:12.672431+00	2025-10-26 11:27:12.702311+00	2025-10-26 11:27:12.666187+00	openai-developing-generative-music-tool	images/blog/article/openai-reveals-how-people-are-using-chatgpwebp79279.webp	7	2
6	آمازون باگ سیستم اتوماسیون خود را به‌عنوان دلیل قطعی گسترده AWS معرفی کرد	بروز این اشکال باعث بروز مشکلات بیشتری در سایر سیستم‌هایی شد که به این نرم‌افزار وابسته بودند. آمازون در ادامه توضیح داده که DynamoDB صدها هزار رکورد DNS را مدیریت می‌کند و باید بتواند هرگونه مشکل را به‌صورت خودکار برطرف کند. اما در تاریخ ۲۰ اکتبر، سیستم مدیریت DNS در DynamoDB دچار باگی شد که منجر به ایجاد رکورد DNS خالی برای مراکز داده آمازون در شمال ویرجینیا گردید. ظاهراً قرار بود DynamoDB این مشکل را به‌صورت خودکار رفع کند، اما این کار انجام نشد و آمازون مجبور شد به‌صورت دستی مشکل را برطرف کند.	t	2025-10-26 11:28:25.94453+00	2025-10-26 11:28:25.999206+00	2025-10-26 11:28:25.939616+00	automation-bug-caused-massive-aws-outage	images/blog/article/amazon-aws96285.webp	7	2
7	بررسی گلکسی S25 FE؛ پرچمدار اقتصادی سامسونگ با فرمول درست	در سال‌های اخیر قیمت گوشی‌های هوشمند به شکل محسوسی افزایش پیدا کرده و همین موضوع باعث شد سامسونگ برای پاسخ به نیاز کاربران، سری Fan Edition یا همان FE را معرفی کند؛ خانواده‌ای که هدف آن ارائه تجربه‌ای نزدیک به پرچمداران اصلی اما با قیمتی مقرون‌به‌صرفه است. حالا پس از گذشت پنج سال از عرضه نخستین مدل در سال ۲۰۲۰، شاهد معرفی تازه‌ترین عضو این مجموعه یعنی گلکسی S25 FE هستیم.	t	2025-10-26 11:29:22.38082+00	2025-10-26 11:29:22.420128+00	2025-10-26 11:29:22.374078+00	galaxy-s25-fe-review	images/blog/article/DigiPics-S25-Fe-1webp72346.webp	7	3
8	بررسی لپ‌تاپ MSI Raider GE78 HX 14V: یک غول قدرتمند در دنیای گیمینگ	لپ‌تاپ MSI Raider GE78 HX 14V به عنوان یکی از قدرتمندترین دستگاه‌های گیمینگ و پردازش حرفه‌ای موجود در بازار شناخته می‌شود. این لپ‌تاپ با ترکیب پردازنده‌های قوی و کارت گرافیک پیشرفته، به‌خصوص برای کاربرانی که به دنبال تجربه‌ای بی‌نظیر در دنیای گیمینگ و کارهای سنگین پردازشی هستند، مناسب است. در ادامه، به بررسی جامع مشخصات فنی و عملکرد این دستگاه می‌پردازیم تا بتوانید درک بهتری از قدرت و قابلیت‌های آن داشته باشید.	t	2025-10-26 11:30:31.552252+00	2025-10-26 11:30:31.582717+00	2025-10-26 11:30:31.546267+00	msi-raider-ge78-hx-14v-review	images/blog/article/DigiPics-MSI-Raiderwebp68471.webp	7	3
9	تحقیق جدید: مغز مردان با افزایش سن سریع‌تر از مغز زنان کوچک می‌شود	یک تیم بین‌المللی از محققان به سرپرستی دانشگاه اسلو در نروژ ۱۲ هزار و ۶۳۸ اسکن MRI مغز از ۴ هزار و ۷۲۶ فرد سالم بین سنین ۱۷ تا ۹۵ سال را تجزیه‌وتحلیل کردند. هر فرد حداقل دو اسکن مغزی به فاصله زمانی متوسط ۳ سال داشت که به محققان امکان می‌داد تغییرات ساختاری مغز را در طول زمان به دقت بررسی کنند.	t	2025-10-26 11:31:51.09643+00	2025-10-26 11:31:51.135806+00	2025-10-26 11:31:51.091908+00	male-brains-shrink-faster-than-female	images/blog/article/male-brains-shrink-faster-than-femalewebp96191.webp	8	4
10	تحقیقات علمی فواید کراتین را نشان داد: از تقویت عملکرد مغز تا کمک به بهبود افسردگی	براساس گزارش BBC، کراتین یک ماده شیمیایی مهم است که به‌طور طبیعی در بدن ما تولید و در عضلات و مغزمان ذخیره می‌شود. وظیفه اصلی آن مدیریت و تأمین انرژی سریع برای سلول‌هاست. در‌حالی‌که تمرکز اکثر تحقیقات روی نقش آن در عضلات بوده، طی سال‌های اخیر دانشمندان در پژوهش‌های مختلف دریافته‌اند که مغز نیز به این منبع انرژی وابسته است.\r\n\r\nبرای مثال، سال گذشته محققان در مطالعه‌ای تأثیر یک دوز کراتین را بر روی عملکرد شناختی افراد پس از یک شب بی‌خوابی کامل بررسی کردند. نتایج نشان داد که سرعت پردازش اطلاعات در گروهی که کراتین مصرف کرده بودند، به‌طور قابل توجهی سریع‌تر از گروه دارونما بود. فرضیه این است که وقتی نورون‌های مغز تحت تنش (مانند بی‌خوابی) قرار می‌گیرند، برای تأمین انرژی مورد نیاز خود، کراتین بیشتری جذب می‌کنند.	t	2025-10-26 11:32:47.821989+00	2025-10-26 11:32:47.872047+00	2025-10-26 11:32:47.810631+00	creatine-boosts-brainpower	images/blog/article/creatine-boosts-brainpower-۲webp18232.webp	8	4
11	جهشی بزرگ در دقت ویرایش ژن؛ دانشمندان MIT نرخ خطا را به‌طرز چشمگیری کاهش دادند	براساس گزارش SciTechDaily، راه‌حل تیم MIT برپایه مهندسی دقیق پروتئین Cas9 (همان قیچی مولکولی در سیستم کریسپر) است. آنها دریافتند که برخی نسخه‌های جهش‌یافته این پروتئین، به جای اینکه همیشه در یک نقطه ثابت برش ایجاد کنند، گاهی اوقات برش خود را یک یا دو باز (Base) جلوتر در توالی DNA انجام می‌دهند.	t	2025-10-26 11:33:52.561709+00	2025-10-26 11:33:52.589622+00	2025-10-26 11:33:52.557603+00	new-level-of-precision-in-gene-editing	images/blog/article/new-level-of-precision-in-gene-editinwebp19422.webp	8	4
12	تپسی سیستم تطبیق چهره آنلاین را برای افزایش امنیت سفرها راه‌اندازی کرد	به گزارش روابط عمومی تپسی، بر اساس این قابلیت جدید، در صورت ثبت گزارش از سوی مسافر، هنگام ورود سفیر به اپلیکیشن، پیغامی برای او نمایش داده می‌شود و از وی خواسته می‌شود تا عکس زنده خود را برای احراز هویت ثبت و بارگذاری کند. این تصویر به وسیله ابزارهای هوش مصنوعی با عکس پروفایل سفیر تطبیق داده می‌شود و در صورت تأیید عدم تطابق، حساب کاربری سفیر تا زمان بررسی و تماس واحد امنیت، به‌صورت موقت غیرفعال خواهد شد و سفیر امکان دریافت سفر را نخواهد داشت، مگر آن‌که سیستم تطبیق چهره، گزارش اعلام‌شده را مردود تشخیص دهد.	t	2025-10-26 11:34:49.97607+00	2025-10-26 11:34:50.019254+00	2025-10-26 11:34:49.970292+00	tapsi-launches-online-face-matching-system	images/blog/article/Tapsi-Facial-Recognition-Safety-PR-Coverwebp40991.webp	8	2
17	انویدیا نخستین شرکت جهان با ارزش بازار 5 تریلیون دلاری شد	شرکت انویدیا روز چهارشنبه به یک دستاورد تاریخی جدید رسید و به اولین شرکتی در جهان تبدیل شد که ارزش بازار آن به 5 تریلیون دلار رسیده است. براساس گزارش‌ها، ارزش این شرکت اکنون از تولید ناخالص داخلی همه کشورهای جهان به جز ایالات متحده و چین بیشتر است. تنها سه ماه قبل، ارزش انویدیا 4 تریلیون دلار بود و حدود دو سال پیش، این عدد 1 تریلیون دلار برآورد می‌شد.	t	2025-11-03 09:13:11.311819+00	2025-11-03 09:13:11.32942+00	2025-11-03 09:13:11.149835+00	nvidia-5-trillion-valuation-ai	images/blog/article/nvidia-5-trillion-valuationwebp52663.webp	6	2
18	دانشمندان با ریاضیات ثابت کردند: جهان ما شبیه‌سازی کامپیوتری نیست	فیزیک مدرن به فراتر از اشیا ملموس نیوتنی نگاه می‌کند. نظریه گرانش کوانتومی نشان می‌دهد که حتی فضا و زمان نیز چیزهایی بنیادی نیستند. آنها از چیزی عمیق‌تر پدیدار می‌شوند: اطلاعات خالص. این اطلاعات در جایی وجود دارد که فیزیکدانان آن را «قلمرو افلاطونی» می‌نامند؛ یک بنیان ریاضیاتی که از جهان فیزیکی که ما تجربه می‌کنیم، واقعی‌تر است. اینجاست که این شک و گمان ایجاد می‌شود که این اطلاعات می‌تواند شبیه به کدهای یک شبیه‌سازی کامپیوتری باشد. اما اکنون محققان نشان دادند که حتی این بنیان مبتنی‌بر اطلاعات نیز نمی‌تواند واقعیت را فقط با محاسبات و الگوریتم‌ها تعریف کند.	t	2025-11-03 09:14:41.363017+00	2025-11-03 09:14:41.368557+00	2025-11-03 09:14:41.358056+00	universe-not-a-simulation-mathematical-proof	images/blog/article/universe-not-a-simulation-mathematicalwebp73766.webp	6	1
19	کشف جدید دانشمندان: اسکلت منتسب به تی‌رکس نابالغ یک گونه مستقل است	به گفته «لیندزی زانو» از موزه علوم طبیعی کارولینای شمالی، این کشف می‌تواند دهه‌ها تحقیقات درباره معروف‌ترین شکارچی زمین را بازنویسی کند. بررسی حلقه‌های رشد استخوان‌ها نشان می‌دهد که این دایناسور بالغ بوده است، اما اندازه آن تقریباً نصف T. rex بالغ است. همچنین تحلیل ساختار جمجمه، الگوهای عصبی و سینوس‌ها نشان می‌دهد که تفاوت‌های آن با T. rex بالغ نمی‌تواند تنها ناشی از بلوغ باشد و نشانه‌ای از یک گونه مستقل است.	t	2025-11-03 09:16:54.611973+00	2025-11-03 09:16:54.61746+00	2025-11-03 09:16:54.607286+00	t-rex-relative-nanotyrannus-lancensis-discovery	images/blog/article/t-rex-relative-nanotyrannus-lancensis-discoverywebp86849.webp	6	3
\.


--
-- Data for Name: comments_blogcomment; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.comments_blogcomment (id, fullname, comment_text, is_active, created_date, published_date, article_id, commenting_user_id) FROM stdin;
2	رضا بختیاری	خیلی جالب بود	t	2025-10-27 16:23:53.559063+00	2025-10-27 16:23:53.558665+00	2	6
1	رضا بختیاری	بسیار مقاله مفیدی در حوزه سلامت بود	t	2025-10-27 16:02:43.381863+00	2025-10-27 16:02:43.381476+00	10	6
3	سنا بخشی	جالبه این قابلیت تپسی	t	2025-10-27 20:58:00.186905+00	2025-10-27 20:58:00.186724+00	12	7
4	سنا بخشی	این قابلیت هوش مصنوعی هم بدک نیست	t	2025-10-27 20:58:59.20784+00	2025-10-27 20:58:59.207612+00	5	7
5	سنا بخشی	میتونست بهتر ازین باشه	t	2025-10-27 20:59:58.728599+00	2025-10-27 20:59:58.728464+00	4	7
6	سنا بخشی	خیلی خوبه این کراتین	t	2025-10-27 21:05:38.312861+00	2025-10-27 21:05:38.312711+00	10	7
39	سنا بخشی	بسیار کابردی و باحاله	t	2025-10-28 09:25:14.588082+00	2025-10-28 09:25:14.587817+00	1	7
40	سنا بخشی	بسیار بد شد :/	t	2025-10-28 09:26:04.821081+00	2025-10-28 09:26:04.820945+00	6	7
41	رضا بختیاری	خیلی خفنه	t	2025-10-28 11:08:21.719754+00	2025-10-28 11:08:21.719398+00	8	6
42	رضا بختیاری	بسیار عالی	t	2025-11-06 08:08:33.854898+00	2025-11-06 08:08:33.854486+00	11	6
43	رضا بختیاری	بسیار عالی	t	2025-11-06 08:11:13.00458+00	2025-11-06 08:11:13.004263+00	19	6
45	رضا بختیاری	بسیار جالبه	t	2025-11-06 08:30:38.011192+00	2025-11-06 08:30:38.010734+00	18	6
44	رضا بختیاری	خیلی خوب	t	2025-11-06 08:28:23.876242+00	2025-11-06 08:28:23.876014+00	18	6
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-10-18 16:57:46.255566+00	2	hasan_rajabi@gmail.com	1	[{"added": {}}]	6	1
2	2025-10-18 16:58:07.070558+00	2	hasan_rajabi@gmail.com	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	6	1
3	2025-10-22 15:33:14.485026+00	1	علمی	1	[{"added": {}}]	42	1
4	2025-10-22 15:33:31.60532+00	2	پژوهشی	1	[{"added": {}}]	42	1
5	2025-10-22 15:33:54.196138+00	3	تکنولوژی	1	[{"added": {}}]	42	1
6	2025-10-22 15:34:13.731817+00	4	هنری	1	[{"added": {}}]	42	1
7	2025-10-22 15:34:24.586363+00	5	داستانی	1	[{"added": {}}]	42	1
8	2025-10-23 14:17:08.326829+00	2	گوگل پلتفرم آموزشی جدیدی با 3000 دوره و آزمایشگاه آنلاین راه‌اندازی کرد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
9	2025-10-23 14:19:04.946926+00	1	متا ۶۰۰ نفر از تیم هوش مصنوعی خود را اخراج کرد	2	[]	43	1
10	2025-10-23 14:26:15.653397+00	6	گارمین از دو ساعت هوشمند جدید برای خلبانی رونمایی کرد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
11	2025-10-23 14:26:48.801156+00	5	پورشه ماکان GTS برقی ۲۰۲۶ معرفی شد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
12	2025-10-23 14:27:09.705393+00	2	گوگل پلتفرم آموزشی جدیدی با 3000 دوره و آزمایشگاه آنلاین راه‌اندازی کرد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
13	2025-10-23 14:27:29.666656+00	3	چین با سریع‌ترین قطار جهان رکوردشکنی کرد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
14	2025-10-23 14:28:05.855129+00	1	متا ۶۰۰ نفر از تیم هوش مصنوعی خود را اخراج کرد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
15	2025-10-23 16:06:55.369548+00	7	ردیت از Perplexity به‌دلیل سرقت داده برای هوش مصنوعی شکایت کرد	2	[{"changed": {"fields": ["Slug"]}}]	43	1
16	2025-10-26 11:06:40.9659+00	1	علمی	1	[{"added": {}}]	42	1
17	2025-10-26 11:06:48.405665+00	2	تکنولوژی	1	[{"added": {}}]	42	1
18	2025-10-26 11:07:09.113082+00	3	پژوهشی	1	[{"added": {}}]	42	1
19	2025-10-26 11:07:49.969686+00	4	پزشکی	1	[{"added": {}}]	42	1
20	2025-10-27 15:37:12.814814+00	6	reza_bakht@gmail.com	2	[{"changed": {"fields": ["\\u0646\\u0627\\u0645", "\\u0641\\u0627\\u0645\\u06cc\\u0644\\u06cc", "\\u062c\\u0646\\u0633\\u06cc\\u062a"]}}]	7	1
21	2025-10-27 20:46:18.132389+00	2	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
22	2025-10-27 20:46:18.135341+00	1	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
23	2025-10-27 20:58:16.886053+00	3	سنا بخشی	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
24	2025-10-27 20:59:16.632318+00	4	سنا بخشی	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
25	2025-10-27 21:00:05.330685+00	5	سنا بخشی	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
26	2025-10-27 21:05:51.363404+00	6	سنا بخشی	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
59	2025-10-28 09:25:39.110847+00	39	سنا بخشی	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
60	2025-10-28 09:26:09.414174+00	40	سنا بخشی	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
61	2025-10-28 11:08:38.469081+00	41	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
62	2025-11-01 10:52:44.905991+00	1	every 5 minutes	1	[{"added": {}}]	37	1
63	2025-11-01 10:53:48.947512+00	2	Remove Inactive Article: every 5 minutes	1	[{"added": {}}]	38	1
64	2025-11-06 08:08:43.840512+00	42	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
65	2025-11-06 08:11:28.942968+00	43	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
66	2025-11-06 08:30:48.122535+00	45	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
67	2025-11-06 08:30:48.127787+00	44	رضا بختیاری	2	[{"changed": {"fields": ["\\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644"]}}]	44	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	UTC
2	0	4	*	*	*	Asia/Tehran
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
1	5	minutes
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
2	Remove Inactive Article	apps.blog.tasks.get_send_email	[]	{}	\N	\N	\N	\N	t	2025-11-09 11:17:57.960553+00	129	2025-11-09 11:18:43.096517+00		\N	1	\N	f	\N	\N	{}	\N	\N
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	\N	0	2025-11-09 05:35:22.512268+00		2	\N	\N	f	\N	\N	{}	\N	43200
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2025-11-09 05:35:22.513334+00
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-10-18 10:28:03.478065+00
2	contenttypes	0002_remove_content_type_name	2025-10-18 10:28:03.482437+00
3	auth	0001_initial	2025-10-18 10:28:03.5152+00
4	auth	0002_alter_permission_name_max_length	2025-10-18 10:28:03.51898+00
5	auth	0003_alter_user_email_max_length	2025-10-18 10:28:03.523225+00
6	auth	0004_alter_user_username_opts	2025-10-18 10:28:03.528727+00
7	auth	0005_alter_user_last_login_null	2025-10-18 10:28:03.53243+00
8	auth	0006_require_contenttypes_0002	2025-10-18 10:28:03.534243+00
9	auth	0007_alter_validators_add_error_messages	2025-10-18 10:28:03.53996+00
10	auth	0008_alter_user_username_max_length	2025-10-18 10:28:03.543764+00
11	auth	0009_alter_user_last_name_max_length	2025-10-18 10:28:03.547229+00
12	auth	0010_alter_group_name_max_length	2025-10-18 10:28:03.551701+00
13	auth	0011_update_proxy_permissions	2025-10-18 10:28:03.554874+00
14	auth	0012_alter_user_first_name_max_length	2025-10-18 10:28:03.558132+00
15	accounts	0001_initial	2025-10-18 10:28:03.605175+00
16	admin	0001_initial	2025-10-18 10:28:03.622041+00
17	admin	0002_logentry_remove_auto_add	2025-10-18 10:28:03.626998+00
18	admin	0003_logentry_add_action_flag_choices	2025-10-18 10:28:03.633266+00
19	sessions	0001_initial	2025-10-18 10:28:03.644309+00
34	authtoken	0001_initial	2025-10-20 09:07:22.787886+00
35	authtoken	0002_auto_20160226_1747	2025-10-20 09:07:22.809862+00
36	authtoken	0003_tokenproxy	2025-10-20 09:07:22.813408+00
37	authtoken	0004_alter_tokenproxy_options	2025-10-20 09:07:22.817821+00
38	django_celery_beat	0001_initial	2025-10-20 09:07:22.871704+00
39	django_celery_beat	0002_auto_20161118_0346	2025-10-20 09:07:22.889145+00
40	django_celery_beat	0003_auto_20161209_0049	2025-10-20 09:07:22.899546+00
41	django_celery_beat	0004_auto_20170221_0000	2025-10-20 09:07:22.90422+00
42	django_celery_beat	0005_add_solarschedule_events_choices	2025-10-20 09:07:22.909914+00
43	django_celery_beat	0006_auto_20180322_0932	2025-10-20 09:07:22.949869+00
44	django_celery_beat	0007_auto_20180521_0826	2025-10-20 09:07:22.966594+00
45	django_celery_beat	0008_auto_20180914_1922	2025-10-20 09:07:22.995671+00
46	django_celery_beat	0006_auto_20180210_1226	2025-10-20 09:07:23.013879+00
47	django_celery_beat	0006_periodictask_priority	2025-10-20 09:07:23.02508+00
48	django_celery_beat	0009_periodictask_headers	2025-10-20 09:07:23.034786+00
49	django_celery_beat	0010_auto_20190429_0326	2025-10-20 09:07:23.18949+00
50	django_celery_beat	0011_auto_20190508_0153	2025-10-20 09:07:23.211653+00
51	django_celery_beat	0012_periodictask_expire_seconds	2025-10-20 09:07:23.221313+00
52	django_celery_beat	0013_auto_20200609_0727	2025-10-20 09:07:23.232483+00
53	django_celery_beat	0014_remove_clockedschedule_enabled	2025-10-20 09:07:23.239072+00
54	django_celery_beat	0015_edit_solarschedule_events_choices	2025-10-20 09:07:23.244473+00
55	django_celery_beat	0016_alter_crontabschedule_timezone	2025-10-20 09:07:23.254715+00
56	django_celery_beat	0017_alter_crontabschedule_month_of_year	2025-10-20 09:07:23.267294+00
57	django_celery_beat	0018_improve_crontab_helptext	2025-10-20 09:07:23.276007+00
58	django_celery_beat	0019_alter_periodictasks_options	2025-10-20 09:07:23.279714+00
63	blog	0001_initial	2025-10-26 10:50:10.903462+00
64	blog	0002_alter_article_author_alter_article_category	2025-10-26 10:50:10.933569+00
65	blog	0003_alter_article_article_text	2025-10-26 10:50:10.942188+00
66	comments	0001_initial	2025-10-26 10:50:10.97314+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: post_user
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
q0yii2kk744pcrsevtixjul9uh551wq5	.eJxVjMsOwiAQRf-FtSE8ygAu3fsNBJhBqgaS0q6M_65NutDtPefcFwtxW2vYBi1hRnZmkp1-txTzg9oO8B7brfPc27rMie8KP-jg1470vBzu30GNo35rbalIjAQpO-uttmAckMjSGIekrdBeg3K6kJuKtAYwK4EToALnUSF7fwDSwzc4:1vAAYm:i8MtAyivdR4OtA2HBLxcnNVnvUBQpxCrMp36paFF0vU	2025-11-01 17:17:40.09527+00
fosxzqwpynkw68p1sws0z5glnz3bdndb	.eJxVjEEOwiAQRe_C2pACM0BduvcMZBhAqoYmpV0Z765NutDtf-_9lwi0rTVsPS9hSuIsrDj9bpH4kdsO0p3abZY8t3WZotwVedAur3PKz8vh_h1U6vVbj9qjAcs2oh0AtVHKelAIlFWB5MbC5NgTKDIqsnPFWNQFiTVrg4N4fwCvPDbc:1vF4pU:kVUihmFSsUJkEU55kKcfjAc-wmYsOZ9jPerzzr5mNXI	2025-11-15 06:11:12.311762+00
3ohtq48geqa3otui3tkekq9eklahdm6j	.eJxVjEEOwiAQRe_C2pBBOkJcuvcMZGAGqRpISrtqvLtt0oVu_3vvryrQMpewdJnCyOqqjDr9bpHSS-oO-En10XRqdZ7GqHdFH7Tre2N53w7376BQL1udwVqIyUsWBiuYjbOeIyA5Mo4cY8JkbUQ_ZJEB_GXTBuRzRDDITn2-9YE38Q:1vHxyW:76nTRR5_OTrRI6D1ht8w55ZaUFmTKjoGCBrfnq1cQIg	2025-11-23 05:28:28.593745+00
7zyd2qk78hqlcvkb6wlozrhjgvqp3wbl	.eJxVjDEOwjAMRe-SGUUJTq2WkZ0zRHYckwJKpaadKu4OlTrA-t97fzOR1qXEteU5jmIuBs3pd2NKz1x3IA-q98mmqS7zyHZX7EGbvU2SX9fD_Tso1Mq3HvrOefSJHJOkwGdAVBkY1bMgOO-UKCD7QNgrIDAygLIQaBLuzPsD7Qs4pQ:1vHy6E:thrwGP5lFJX27zjIhvGoBPULRWrDW3E0LXdcBPOSnqc	2025-11-23 05:36:26.042528+00
\.


--
-- Name: accounts_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.accounts_customuser_groups_id_seq', 1, false);


--
-- Name: accounts_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.accounts_customuser_id_seq', 13, true);


--
-- Name: accounts_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.accounts_customuser_user_permissions_id_seq', 1, false);


--
-- Name: accounts_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.accounts_profile_id_seq', 13, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 77, true);


--
-- Name: blog_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.blog_article_id_seq', 19, true);


--
-- Name: blog_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.blog_category_id_seq', 4, true);


--
-- Name: comments_blogcomment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.comments_blogcomment_id_seq', 45, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 67, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 2, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, true);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 2, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 44, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: post_user
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 66, true);


--
-- PostgreSQL database dump complete
--

\unrestrict AdbcQ9PbbBwJz1K35znkuncsQZPsX5t4uY7i8pzsxZ24qnI1de5rlIO5V8gZOXF

